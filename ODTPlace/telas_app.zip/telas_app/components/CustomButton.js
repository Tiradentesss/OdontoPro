import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  Dimensions,
} from 'react-native';

const { width } = Dimensions.get('window');

export default function CustomButton({ title, onPress }) {
  return (
    <TouchableOpacity
      style={styles.button}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <Text style={styles.text}>
        {title}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    marginTop: 25,

    backgroundColor: '#fff',

    width: width * 0.82, // 82% da largura da tela
    height: 56,

    borderRadius: 14,

    justifyContent: 'center',
    alignItems: 'center',

    alignSelf: 'center',
  },

  text: {
    color: '#000',
    fontSize: 17,
    fontWeight: '700',
  },
});