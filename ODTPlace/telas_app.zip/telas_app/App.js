import React from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './src/screens/HomeScreen';
import HomeProfissional from './src/screens/HomeProfissional';
import LoginScreen from './src/screens/LoginScreen';
import LoginProfissional from './src/screens/LoginProfissional';
import SplashScreen from './src/screens/SplashScreen';
import CadastroScreen from './src/screens/CadastroScreen';
import ClinicDetailScreen from './src/screens/ClinicDetailScreen';
import ScheduleScreen from './src/screens/ScheduleScreen';
import ProfessionalsScreen from './src/screens/ProfessionalsScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import NotificationsScreen from './src/screens/NotificationsScreen';
import PreLogin from './src/screens/PreLogin';
import ForgotPassword from './src/screens/ForgotPassword';
import CheckEmail from './src/screens/CheckEmail';
import NewPassword from './src/screens/NewPassword';
import CadastroP from './src/screens/CadastroP';
import ForgotPasswordP from './src/screens/ForgotPasswordP';
import CheckEmailP from './src/screens/CheckEmailP';
import NewPasswordP from './src/screens/NewPasswordP';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>

      <Stack.Navigator screenOptions={{ headerShown: false }}>

        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="PreLogin" component={PreLogin} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="LoginProfissional" component={LoginProfissional} />
        <Stack.Screen name="Cadastro" component={CadastroScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="HomeP" component={HomeProfissional} />
        <Stack.Screen name="Schedule" component={ScheduleScreen} />
        <Stack.Screen name="ClinicDetail" component={ClinicDetailScreen} />
        <Stack.Screen name="Professionals" component={ProfessionalsScreen} />
        <Stack.Screen name="Notifications" component={NotificationsScreen} />
        <Stack.Screen name="Settings" component={SettingsScreen} />
        <Stack.Screen name="ForgotPassword" component={ForgotPassword} />
        <Stack.Screen name="CheckEmail" component={CheckEmail} />
        <Stack.Screen name="NewPassword" component={NewPassword} />
        <Stack.Screen name="CadastroP" component={CadastroP} />
        <Stack.Screen name="ForgotPasswordP" component={ForgotPasswordP} />
        <Stack.Screen name="CheckEmailP" component={CheckEmailP} />
        <Stack.Screen name="NewPasswordP" component={NewPasswordP} />
      </Stack.Navigator>

    </NavigationContainer>
  );
}
